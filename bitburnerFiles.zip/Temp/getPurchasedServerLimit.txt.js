export async function main(ns) { let r;try{r=JSON.stringify(
    ns.getPurchasedServerLimit()
);}catch(e){r="ERROR: "+(typeof e=='string'?e:e.message||JSON.stringify(e));}
const f="/Temp/getPurchasedServerLimit.txt"; if(ns.read(f)!==r) ns.write(f,r,'w') }
export async function main(ns) { let r;try{r=JSON.stringify(
    Object.fromEntries([...Array(30).keys()].map(i => [i, ns.getPurchasedServerCost(2**i)]))
);}catch(e){r="ERROR: "+(typeof e=='string'?e:e.message||JSON.stringify(e));}
const f="/Temp/host-costs.txt"; if(ns.read(f)!==r) ns.write(f,r,'w') }
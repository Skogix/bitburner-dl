export async function main(ns) { let r;try{r=JSON.stringify(
    ns.scp(ns.args.slice(2), ns.args[0], ns.args[1])
);}catch(e){r="ERROR: "+(typeof e=='string'?e:e.message||JSON.stringify(e));}
const f="/Temp/copy-scripts.txt"; if(ns.read(f)!==r) ns.write(f,r,'w') }
export async function main(ns) { let r;try{r=JSON.stringify(
    Object.fromEntries(ns.args.map(server => [server, ns.getServer(server)]))
);}catch(e){r="ERROR: "+(typeof e=='string'?e:e.message||JSON.stringify(e));}
const f="/Temp/getServer-all.txt"; if(ns.read(f)!==r) ns.write(f,r,'w') }
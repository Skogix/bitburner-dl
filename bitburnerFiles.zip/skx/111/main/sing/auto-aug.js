/*

Auto find and purchase augs, try to bribe using corporate funds?
 
*/

/** @param {NS} ns */
export async function main(ns) {
  ns.corporation.bribe()
}
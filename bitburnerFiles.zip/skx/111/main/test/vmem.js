/*

VM - your virtual memory assistant

It uses eval which is kinda cheaty to keep track of things, but it is based on running 'scan'
which writes a list of servers and their memory to /var/servers.txt.  Therefore it only really
runs well on 'home'.

*/

// 1 + 3 + 7 * 7 + 14 * 6 + 29 * 2
// 195 threads, weaken by 9.75 difficulty in 10 minutes

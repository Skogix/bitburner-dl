/** @param {import("/.").NS} ns */
export async function main(ns) {
    ns.disableLog("ALL")
    let server_name = "joesguns"
    if (ns.args.length > 0) {
        server_name = ns.args[0]
    }
    let hackPercent = 0.5
    if (ns.args.length > 1) {
        hackPercent = ns.args[1]
    }

    ns.run("do_batch.js", 1, server_name, hackPercent)
}
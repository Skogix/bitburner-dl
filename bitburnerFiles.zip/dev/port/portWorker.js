export async function main(ns, target, delay, port, security, hackingLevel) {
  if (target == void 0 || delay == void 0 || port == void 0 || security == void 0 || hackingLevel == void 0) {
    ns.tprint("FAIL: Missing some arguments?!");
    return;
  }
  await ns.sleep(delay);
  const portData = JSON.parse(ns.peek(port));
  if (portData.security != security) {
    ns.tprint("FAIL: Security is " + portData.security + " expected " + security + " aborting!");
    return;
  }
  if (portData.hackLevel != hackingLevel) {
    ns.tprint("FAIL: Hack level is " + portData.hackLevel + " expected " + hackingLevel + " aborting!");
    return;
  }
  await ns.hack(target);
}

export async function main(ns) {
  const target = ns.getServer("n00dles");
  const port2 = 0;
  let oldMessage = "";
  ns.tail();
  ns.disableLog("ALL");
  while (true) {
    const message = JSON.stringify({ target });
    if (message.toString() != oldMessage.toString()) {
      ns.clearPort(port2);
      const result = ns.writePort(port2, message);
      ns.print(`
port full?: ${ns.getPortHandle(port2).full()}
port: ${port2}
data: ${message}
result: ${result}`);
      oldMessage = message;
    }
    await ns.sleep(1 * 1e3);
  }
}

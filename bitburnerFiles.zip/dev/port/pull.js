export async function main(ns) {
  ns.disableLog("ALL");
  const triggerPort = ns.getPortHandle(10);
  const pullPort = ns.getPortHandle(20);
  triggerPort.clear();
  pullPort.clear();
  let checksum = 0;
  while (true) {
    const start = performance.now();
    const command = checksum.toString();
    triggerPort.write(command);
    await pullPort.nextWrite();
    const reply = pullPort.read();
    const elapsed = performance.now() - start;
    ns.print("WARN: Sent: + " + checksum + " Reply: " + reply + " elapsed: " + elapsed.toFixed(3) + "ms");
    checksum++;
    ns.print("");
    await ns.sleep(250);
  }
}

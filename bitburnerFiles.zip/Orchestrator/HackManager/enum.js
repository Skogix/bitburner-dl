export var RequiredScript = /* @__PURE__ */ ((RequiredScript2) => {
  RequiredScript2["hack"] = "hack";
  RequiredScript2["weaken"] = "weaken";
  RequiredScript2["grow"] = "grow";
  RequiredScript2["xp"] = "xp";
  return RequiredScript2;
})(RequiredScript || {});
export var HackType = /* @__PURE__ */ ((HackType2) => {
  HackType2["growWeakenHack"] = "growWeakenHack";
  HackType2["moneyHack"] = "moneyHack";
  HackType2["xpHack"] = "xpHack";
  return HackType2;
})(HackType || {});
export var HackMode = /* @__PURE__ */ ((HackMode2) => {
  HackMode2["money"] = "money";
  HackMode2["xp"] = "xp";
  return HackMode2;
})(HackMode || {});

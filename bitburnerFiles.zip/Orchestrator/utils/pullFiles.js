export async function main(ns) {
  return 0;
}

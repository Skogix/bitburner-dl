export const PROGRAMS = [
  { name: "tor", price: 2e5 },
  { name: "brutessh.exe", price: 5e5 },
  { name: "ftpcrack.exe", price: 15e5 },
  { name: "relaysmtp.exe", price: 5e6 },
  { name: "httpworm.exe", price: 3e7 },
  { name: "sqlinject.exe", price: 25e7 }
];
export const COMMIT_CRIME = true;
